# tcpping
Python tcp ping client.

Measures round trip latency, from client to first application gateway.
Estimates the maximum copper reach, from client to first application gateway.
Does not measure round trip latency, from client to server.
