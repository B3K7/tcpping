"""
tcpping
A Python tcpping client
"""


__version__ = "0.1.1"
__author__  = "B3K7"
__credits__ = "B3K7@github.com"
